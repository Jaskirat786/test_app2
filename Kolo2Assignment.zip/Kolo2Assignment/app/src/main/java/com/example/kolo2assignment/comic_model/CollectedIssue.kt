package com.example.kolo2assignment.comic_model

data class CollectedIssue(
    val name: String,
    val resourceURI: String
)
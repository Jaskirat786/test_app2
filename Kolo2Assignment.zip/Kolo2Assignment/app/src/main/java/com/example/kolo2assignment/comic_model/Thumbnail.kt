package com.example.kolo2assignment.comic_model

data class Thumbnail(
    val extension: String,
    val path: String
)
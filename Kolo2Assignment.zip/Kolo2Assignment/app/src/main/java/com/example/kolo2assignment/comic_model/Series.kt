package com.example.kolo2assignment.comic_model

data class Series(
    val name: String,
    val resourceURI: String
)
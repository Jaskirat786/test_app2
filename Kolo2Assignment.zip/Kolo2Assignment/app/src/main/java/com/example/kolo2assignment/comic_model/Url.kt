package com.example.kolo2assignment.comic_model

data class Url(
    val type: String,
    val url: String
)
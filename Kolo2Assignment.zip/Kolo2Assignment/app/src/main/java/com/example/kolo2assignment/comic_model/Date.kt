package com.example.kolo2assignment.comic_model

data class Date(
    val date: String,
    val type: String
)
package com.example.kolo2assignment.comic_model

data class Image(
    val extension: String,
    val path: String
)
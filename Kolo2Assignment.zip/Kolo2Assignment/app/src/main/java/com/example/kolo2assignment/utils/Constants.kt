package com.example.kolo2assignment.utils

class Constants {

    companion object {
        const val URL: String = "https://gateway.marvel.com:443/v1/public/"
        const val APIKEY: String = "4c51496be38b495bf5883e04333d62a6"
        const val hash: String = "779c1c9f4a60700265cd4848703fe403"
        const val ts: String = "1"
    }
}
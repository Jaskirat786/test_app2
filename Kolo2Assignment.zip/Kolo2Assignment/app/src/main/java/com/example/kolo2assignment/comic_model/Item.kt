package com.example.kolo2assignment.comic_model

data class Item(
    val name: String,
    val resourceURI: String
)
package com.example.kolo2assignment.comic_model

data class TextObject(
    val language: String,
    val text: String,
    val type: String
)
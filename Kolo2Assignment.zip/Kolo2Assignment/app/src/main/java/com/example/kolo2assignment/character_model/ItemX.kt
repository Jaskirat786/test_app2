package com.example.kolo2assignment.character_model

data class ItemX(
    val name: String,
    val resourceURI: String
)
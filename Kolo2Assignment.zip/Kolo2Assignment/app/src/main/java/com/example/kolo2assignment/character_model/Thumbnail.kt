package com.example.kolo2assignment.character_model

data class Thumbnail(
    val extension: String,
    val path: String
)
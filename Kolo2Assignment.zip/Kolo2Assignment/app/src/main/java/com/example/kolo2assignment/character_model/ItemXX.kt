package com.example.kolo2assignment.character_model

data class ItemXX(
    val name: String,
    val resourceURI: String
)
package com.example.kolo2assignment.comic_model

data class ItemX(
    val name: String,
    val resourceURI: String,
    val role: String
)
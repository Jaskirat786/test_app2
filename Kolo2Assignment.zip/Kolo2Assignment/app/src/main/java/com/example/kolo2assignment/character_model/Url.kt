package com.example.kolo2assignment.character_model

data class Url(
    val type: String,
    val url: String
)
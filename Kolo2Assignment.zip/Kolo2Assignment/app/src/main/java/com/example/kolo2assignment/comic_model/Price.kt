package com.example.kolo2assignment.comic_model

data class Price(
    val price: Int,
    val type: String
)